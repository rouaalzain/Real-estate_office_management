﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ipg201_F21
{
    public partial class Add_an_aِppointment : Form
    {
        public static Customer loggedCus { get; private set; }


        private DbEntities db = new DbEntities();

        public static void setId1(Customer n)
        {
            loggedCus = n;
        }


        User loggeduser = Login.loggeduser;




        public Add_an_aِppointment()
        {
            InitializeComponent();


            var Prolist = (from s in db.Properties
                           where s.Owner_ID == s.Customer.Id
                           select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.ContractType_, s.TypeOfProperty_ }).ToList();
            dataGridView5.DataSource = Prolist;



        }

        private void AddAppointment_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

            FormHomePageUser f = new FormHomePageUser();
            f.Show();
            this.Hide();

        }

        private int idPro2;


        private void dataGridView5_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idPro2 = Convert.ToInt32(dataGridView5.Rows[e.RowIndex].Cells[0].Value);
            Pro_Num_textBox.Text = Convert.ToString(dataGridView5.Rows[e.RowIndex].Cells[0].Value);
        }


        private void button8_Click(object sender, EventArgs e)
        {

            
            string errormsg = "";
            if (timetextBox1.Text == "")
                errormsg += "أدخل التوقيت\n";
           
            string fullname = fullN_textBox2.Text;
            if (fullname.Trim() == "") errormsg += "أدخال اسم الزبون\n";
            string idnumber = Nn_textBox8.Text;// الرقم الوطني
            if (idnumber == "") errormsg += "أدخال الرقم الوطني\n";
            if (Nn_textBox8.Text == "" || fullN_textBox2.Text == ""
                || mob_textBox3.Text == "" || addresstextBox7.Text == "" 
                || Pro_Num_textBox.Text == ""
                )
                errormsg += "حدد العقار وتأكد من الإدخال\n";
            try
            {

                if (errormsg == "")
            {
                    Customer c = new Customer();
                    c.fullname = fullname;
                    c.address = addresstextBox7.Text;
                    c.idnumber = idnumber;
                    c.phone = mob_textBox3.Text;
                    var id1 = db.Customers.Add(c);// الاضافة
                    db.Customers.Add(c);
                    db.SaveChanges();


                    var uData = db.Customers.Where(x => x.fullname == fullname && x.idnumber == idnumber).FirstOrDefault();
                    loggedCus = uData;

                    MessageBox.Show(" loggedCus== " + loggedCus.Id);

                AppointmentBooking NewApp = new AppointmentBooking();
                 NewApp.Property_ID = Convert.ToInt32(Pro_Num_textBox.Text); ;// رقم العقار

                    NewApp.Booking_date = Convert.ToDateTime(dateTimePicker5.Text);

                    NewApp.Time = Convert.ToInt32(timetextBox1.Text);
                NewApp.User_ID = loggeduser.Id;

                    NewApp.Customer_ID = loggedCus.Id; //الزبون 

                    var id = db.AppointmentBookings.Add(NewApp); // الاضافة

                    db.AppointmentBookings.Add(NewApp);

                    try
                    {
                    db.SaveChanges();
                    MessageBox.Show("تمت الاضافة بنجاح");
                }
                catch (Exception a)
                {
                    MessageBox.Show("الرجاء التحقق من المعلومات");
                }
            }
            else
                MessageBox.Show(errormsg);


            }
            catch (Exception a)
            {
                MessageBox.Show(" تحقق");
            }



        }

        private void Pro_Num_textBox_TextChanged(object sender, EventArgs e)
        {

        }



        //---------------------------------



    }
}
