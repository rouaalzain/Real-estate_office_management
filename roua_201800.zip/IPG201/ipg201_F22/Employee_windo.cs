﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ipg201_F21
{
    public partial class FormHomePageUser : Form
    {
        private DbEntities db = new DbEntities();

       // DbEntities db = new DbEntities();

        User loggeduser = Login.loggeduser;

        public FormHomePageUser()
        {

            InitializeComponent();
            var Appointmen = (from s in db.AppointmentBookings
                              where s.User_ID == loggeduser.Id  && s.Booking_date== DateTime.Today
            select new {  s.Customer.fullname, s.Booking_date, s.Time , s.Property.PropertyNumber , s.Property.Region}).ToList();
            dataGridView1.DataSource = Appointmen;

            var cuslist = (from s in db.Customers
                           select new { s.Id, s.fullname, s.idnumber }).ToList();
            dataGridView4.DataSource = cuslist;



            var Applist = (from s in db.AppointmentBookings
                           where s.User_ID == loggeduser.Id && s.Customer_ID == s.Customer.Id 
                           select new { s.Id, s.Customer.fullname, s.Customer.idnumber , s.Booking_date , s.Time , s.Property.PropertyNumber , s.Property.Region}).ToList();
            dataGridView2.DataSource = Applist;



            
                var Prolist = (from s in db.Properties
                               where  s.Owner_ID == s.Customer.Id
                               select new { s.Id,s.PropertyNumber, s.Customer.fullname, s.ContractType_,  s.TypeOfProperty_ , s.RoomsNumber , s.Area , s.Cost}).ToList();
            dataGridView3.DataSource = Prolist;



            var plist = (from s in db.Properties
                         where (s.User_ID == loggeduser.Id && s.Customer.idnumber.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID) || (s.User_ID == loggeduser.Id && s.Customer.fullname.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID)
                         select new { s.Id, s.PropertyNumber, s.Customer.fullname,s.Customer.idnumber, s.ContractType_, s.TypeOfProperty_ }).ToList();
            dataGrid.DataSource = plist;

        }    

        //-----------------------------------


        private void new_btn_Click_1(object sender, EventArgs e)
        {

            Add_property f = new Add_property();
            f.Show();
            this.Hide();

        }
        
       // public static Property dPropert { get; private set; } = new Property();

        private void search_btn_Click_1(object sender, EventArgs e)
        {

            var cuslist = (from s in db.Customers
             where s.fullname.Contains(search_textbox.Text) || s.idnumber.Contains(search_textbox.Text)
             select new { s.Id, s.fullname, s.idnumber }).ToList();
            dataGridView4.DataSource = cuslist;
           
        }

        private void search_textbox_TextChanged(object sender, EventArgs e)
        {

            var cuslist = (from s in db.Customers
                           where s.fullname.Contains(search_textbox.Text) || s.idnumber.Contains(search_textbox.Text)
                           select new { s.Id, s.fullname, s.idnumber }).ToList();
            dataGridView4.DataSource = cuslist;
        }
        //-------------------------------------------------------------------------
        private void button4_Click(object sender, EventArgs e) // البحث عن عقار حسب المواصفات
        {
            
            var Prolist = (from s in db.Properties
                           where s.ContractType_.Contains(contract_type_comboBox.Text) && s.TypeOfProperty_.Contains(Type_comboBox7.Text)
                           && s.StatusOfProperty_.Contains(Stat_comboBox8.Text)
                           && s.Region.Contains(region_comboBox5.Text)
                           select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.ContractType_, s.TypeOfProperty_, s.RoomsNumber, s.Area , s.Cost }).ToList();
            dataGridView3.DataSource = Prolist;

       
        }
        //-------------------------------------------------------------------------
       

        private void button8_Click(object sender, EventArgs e)
        {
            Pro_groupBox.Enabled = true;

        }
        //-------------------------------------------------------------------------


        private int _idOwner;

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _idOwner = Convert.ToInt32(dataGridView4.Rows[e.RowIndex].Cells[0].Value);

        }

        //-------------------------------------------------------------------------

        private int Appointment_id;

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Appointment_id = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[0].Value);
            Time1textBox1.Text = Convert.ToString(dataGridView2.Rows[e.RowIndex].Cells[4].Value);
            dateTimePicker1.Text = Convert.ToString(dataGridView2.Rows[e.RowIndex].Cells[3].Value);
        }
        private void button7_Click(object sender, EventArgs e)
        {


            var Alist = (from s in db.AppointmentBookings
                         where ((s.User_ID == loggeduser.Id && s.Customer.fullname.Contains(search_textbox2.Text) && s.Customer_ID == s.Customer.Id) || s.User_ID == loggeduser.Id && s.Customer.idnumber.Contains(search_textbox2.Text) && s.Customer_ID == s.Customer.Id)
                         select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
            dataGridView2.DataSource = Alist;

        }

        //-------------------------------------------------------------------------

        private int _idProEdit;
        private void dataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _idProEdit = Convert.ToInt32(dataGrid.Rows[e.RowIndex].Cells[0].Value);
            p_num.Text = Convert.ToString(dataGrid.Rows[e.RowIndex].Cells[1].Value);
            Property A = db.Properties.Find(_idProEdit);
            try
            {
                Type2.Text = Convert.ToString(A.TypeOfProperty_);
                Type1.Text = Convert.ToString(A.ContractType_);
                CostextBox4.Text = Convert.ToString(A.Cost);
                textBox1.Text = Convert.ToString(A.Area);
                Status.Text= Convert.ToString(A.StatusOfProperty_);
                comboBox1.Text= Convert.ToString(A.Region);
                MemoryStream ms = new MemoryStream(A.pic);

            }
            catch
            {
                MessageBox.Show("حدد الموعد المراد تعديله وتحقق من الإدخال");

            }

            

        }


        //-------------------------------------------------------------------------


        private void search_textbox2_TextChanged(object sender, EventArgs e)
        {

            var Alist = (from s in db.AppointmentBookings
                         where ((s.User_ID == loggeduser.Id && s.Customer.fullname.Contains(search_textbox2.Text) && s.Customer_ID==s.Customer.Id) || s.User_ID == loggeduser.Id && s.Customer.idnumber.Contains(search_textbox2.Text) && s.Customer_ID == s.Customer.Id)
                           select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
            dataGridView2.DataSource = Alist;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Edit_groupBox5.Enabled = true;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            AppointmentBooking A = db.AppointmentBookings.Find(Appointment_id);
            try
              {

            A.Booking_date = Convert.ToDateTime( dateTimePicker1.Text);
                A.Time = Convert.ToInt32(Time1textBox1.Text);
            
            db.SaveChanges();
                MessageBox.Show("تم التعديل" + A.Time + A.Booking_date);

                var Applist = (from s in db.AppointmentBookings
                               where s.User_ID == loggeduser.Id && s.Customer_ID == s.Customer.Id
                               select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
                dataGridView2.DataSource = Applist;


            }
              catch
             {
                  MessageBox.Show("حدد الموعد المراد تعديله وتحقق من الإدخال");

             }

        }


        

        //-------------------------------------------------------------------------



        private void Edit_groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)// حذف موعد
        {
            try
            {
                AppointmentBooking m = db.AppointmentBookings.Find(Appointment_id);

            db.AppointmentBookings.Remove(m);

                db.SaveChanges();

                MessageBox.Show( "تم الحذف" );

                var Applist = (from s in db.AppointmentBookings
                               where s.User_ID == loggeduser.Id && s.Customer_ID == s.Customer.Id
                               select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
                dataGridView2.DataSource = Applist;
            

            }
            catch
            {
                MessageBox.Show("حدد الموعد المراد حذفه");

            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //  AddDategroupBox5.Enabled = true;

            Add_an_aِppointment f = new Add_an_aِppointment();
            f.Show();
            this.Hide();

        }




        private void button8_Click_2(object sender, EventArgs e)
        {

            var Prolist = (from s in db.Properties
                           select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.ContractType_, s.TypeOfProperty_, s.RoomsNumber, s.Area, s.Cost }).ToList();
            dataGridView3.DataSource = Prolist;


        }
        //-------------------------------------------------------------------------



        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            var plist = (from s in db.Properties
                         where (s.User_ID == loggeduser.Id && s.Customer.idnumber.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID) || (s.User_ID == loggeduser.Id && s.Customer.fullname.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID)
                         select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.Customer.idnumber, s.ContractType_, s.TypeOfProperty_ }).ToList();
            dataGrid.DataSource = plist;


        }

        private void button12_Click(object sender, EventArgs e)
        {
            groupBox5.Enabled = true;

        }


        //-------------------------------------------------------------------------

        private void button10_Click(object sender, EventArgs e) // التعديل على العقار
        {

            string errormsg = "";
            

            if (p_num.Text == "" || Type2.Text == "" // نوع العقار
                || CostextBox4.Text == "" || textBox1.Text == "" // المساحة والسعر
                || Type1.Text == "" || Status.Text == "" // نوع التعاقد
                || comboBox1.Text == ""  // المنطقة
                )
                errormsg += "تأكد من الإدخال\n";


            Property Property2 = db.Properties.Find(_idProEdit);

           
            try
            {
                if (errormsg == "")
                {

                    Property2.PropertyNumber = Convert.ToInt32(p_num.Text);// رقم العقار
                    Property2.TypeOfProperty_ = Type2.Text; // نوع العقار
                    Property2.StatusOfProperty_ = Status.Text;//حالة العقار
                    Property2.Region = comboBox1.Text;//المنطقة
                    Property2.Area = Convert.ToDecimal(textBox1.Text); // المساحة
                    Property2.ContractType_ = Type1.Text;// نوع التعاقد
                    Property2.RoomsNumber = Convert.ToInt32(numericUpDown1.Text); // عدد الغرف
                    Property2.Cost = Convert.ToInt32(CostextBox4.Text); // قيمة العقار
                   // Property2.registerdate = DateTime.Today;// التاريخ
                    Property2.User_ID = loggeduser.Id;
                    Property2.Owner_ID =Convert.ToInt32(Property2.Owner_ID);//----------------- معرف المالك يلي حددو المستخدم
                    MemoryStream pr = new MemoryStream();
                    Property2.pic = pr.ToArray();
                    try
                    {
                        db.SaveChanges();
                        MessageBox.Show("تم التعديل بنجاح");

                        var plist = (from s in db.Properties
                                     where (s.User_ID == loggeduser.Id && s.Customer.idnumber.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID) || (s.User_ID == loggeduser.Id && s.Customer.fullname.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID)
                                     select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.Customer.idnumber, s.ContractType_, s.TypeOfProperty_ }).ToList();
                        dataGrid.DataSource = plist;

                        var Prolist = (from s in db.Properties
                                       where s.Owner_ID == s.Customer.Id
                                       select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.ContractType_, s.TypeOfProperty_, s.RoomsNumber, s.Area, s.Cost }).ToList();
                        dataGridView3.DataSource = Prolist;



                    }
                    catch (Exception a)
                    {
                        MessageBox.Show("الرجاء التحقق من المعلومات");
                    }

                }
                else
                    MessageBox.Show(errormsg);
            }
            catch (Exception a)
            {
                MessageBox.Show("تحقق من المعلومات");

            }

            


        }
        //-------------------------------------------------------------------------

        

        private void Notes_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {

        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void GroupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void TabPage3_Click(object sender, EventArgs e)
        {

        }

        private void Label33_Click(object sender, EventArgs e)
        {

        }






        //-------------------------------------------------------------------------




    }
}
