﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ipg201_F21
{

    public partial class Add_property : Form
    {
        public static Customer loggedCus { get; private set; }


        private DbEntities db = new DbEntities();

        public static void setId(Customer n)
        {
            loggedCus = n;
        }


        User loggeduser = Login.loggeduser;
         

        public Add_property()
        {
            InitializeComponent();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {

            try { 
            string errormsg = "";            

            string fullname = fullN_textBox2.Text;
            if (fullname.Trim() == "") errormsg += "أدخال اسم الزبون\n";
            string idnumber = Nn_textBox8.Text;// الرقم الوطني
            if (idnumber == "") errormsg += "أدخال الرقم الوطني\n";
            if (used_label.Text != "") errormsg += "أدخال رقم وطني صحيح \n";
            DateTime registerdate = dateTimePicker1.Value;
            if (Pro_N_textBox1.Text == "" || Type_comboBox2.Text == ""
                || cost_textBox4.Text == "" || Area_textBox6.Text == ""
                || Co_Type_comboBox3.Text == "" || stat_comboBox1.Text == ""
                || Region_comboBox4.Text == "" || mob_textBox3.Text == ""
                )
                errormsg += "تأكد من الإدخال\n";

            if (errormsg == "")
            {
                Customer c = new Customer();
                c.fullname = fullname;
                c.idnumber = idnumber;
                c.phone = mob_textBox3.Text;
                var id1 = db.Customers.Add(c);// الاضافة
                db.Customers.Add(c);
                db.SaveChanges();


                var uData = db.Customers.Where(x => x.fullname == fullname && x.idnumber == idnumber).FirstOrDefault();
                loggedCus = uData;
                Property p = new Property();
                p.PropertyNumber = Convert.ToInt32(Pro_N_textBox1.Text);// رقم العقار
                p.TypeOfProperty_ = Type_comboBox2.Text; // نوع العقار
                p.StatusOfProperty_ = stat_comboBox1.Text;//حالة العقار
                p.Region = Region_comboBox4.Text;//المنطقة
                p.Area = Convert.ToDecimal(Area_textBox6.Text); // المساحة
                p.ContractType_ = Co_Type_comboBox3.Text;// نوع التعاقد
                p.RoomsNumber = Convert.ToInt32(Room_UpDown1.Text);
                p.Cost = Convert.ToInt32(cost_textBox4.Text); // قيمة العقار
                p.registerdate = DateTime.Today;// التاريخ
                p.User_ID = loggeduser.Id;
                p.Owner_ID = loggedCus.Id;
                MemoryStream pr = new MemoryStream();
                p.pic = pr.ToArray();
                var id = db.Properties.Add(p);// الاضافة

                db.Properties.Add(p);
                try
                {
                    db.SaveChanges();
                    MessageBox.Show("تمت الاضافة بنجاح");
                }
                catch (Exception a)
                {
                    MessageBox.Show("الرجاء التحقق من المعلومات");
                }
            }
            else
                MessageBox.Show(errormsg);
            }
            catch (Exception a)
            {
                MessageBox.Show("الرجاء التحقق من الرقم الوطني والمعلومات");
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {

            FormHomePageUser f = new FormHomePageUser();
            f.Show();
            this.Hide();
        }

        private void Nn_textBox8_TextChanged(object sender, EventArgs e)
        {

            if (Nn_textBox8.Text != "")
            {
                var res = (from s in db.Customers
                           where s.idnumber == Nn_textBox8.Text
                           select s).ToList();
                bool used = false;
                foreach (var re in res)
                {
                    used = true;
                    break;
                }
                if (used)
                    unameerror.Text = "الرقم الوطني مستخدم سابقاً";
                else
                    unameerror.Text = "";
            }
            else unameerror.Text = "";
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Label15_Click(object sender, EventArgs e)
        {

        }

        private void Used_label_Click(object sender, EventArgs e)
        {

        }

        private void Add_property_Load(object sender, EventArgs e)
        {

        }

        private void Label8_Click(object sender, EventArgs e)
        {

        }








        //--------------------------------------------------------


    }
}
