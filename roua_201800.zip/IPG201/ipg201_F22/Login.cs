﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ipg201_F21
{
    public partial class Login : Form
    {
        public static User loggeduser { get; private set; }

        DbEntities db = new DbEntities();

      
        public Login()
        {
            InitializeComponent();
        }
        public static void setuser(User n)
        {
            loggeduser = n;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // string UserType = comboBoxAccesslevel.SelectedItem.ToString();

            string username = UserName.Text;
            string password = this.passwordIN.Text;

            string UserType = comboBoxAccesslevel.SelectedItem.ToString();
            var uData = db.Users.Where(x => x.username == username && x.password == password && x.accesslevel == UserType).FirstOrDefault();
            if (uData == null)
            {
                MessageBox.Show("اسم المستخدم أو كلمة المرور غير صحيحة");
                this.passwordIN.Clear();
                UserName.Clear();
            }
            else
            {
              

                 loggeduser = uData;

                if (uData.accesslevel == "Admin")
                {
                    AdminWindo f = new AdminWindo();
                    f.Show();
                    this.Hide();
                }
                else
                {
                    FormHomePageUser f = new FormHomePageUser();
                    f.Show();
                    this.Hide();
                }

            }

        }
        //-------------------------------------------------
        


        //-------------------------------------------------

        private void Login_Load(object sender, EventArgs e)
        {
            comboBoxAccesslevel.SelectedIndex = 1;
            
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                passwordIN.PasswordChar = '\0';
            }
            else
            {
                passwordIN.PasswordChar = '*';
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            UserName.Text = "";
            passwordIN.Text = "";
        }
    }
}
