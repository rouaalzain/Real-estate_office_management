﻿
namespace ipg201_F21
{
    partial class Add_property
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_property));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Pro_N_textBox1 = new System.Windows.Forms.TextBox();
            this.fullN_textBox2 = new System.Windows.Forms.TextBox();
            this.mob_textBox3 = new System.Windows.Forms.TextBox();
            this.cost_textBox4 = new System.Windows.Forms.TextBox();
            this.stat_comboBox1 = new System.Windows.Forms.ComboBox();
            this.Type_comboBox2 = new System.Windows.Forms.ComboBox();
            this.Co_Type_comboBox3 = new System.Windows.Forms.ComboBox();
            this.Region_comboBox4 = new System.Windows.Forms.ComboBox();
            this.Room_UpDown1 = new System.Windows.Forms.NumericUpDown();
            this.Area_textBox6 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.Nn_textBox8 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.unameerror = new System.Windows.Forms.Label();
            this.used_label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Room_UpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(601, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Block number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(601, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Space";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(595, 381);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Full Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(595, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Type of Contract";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(595, 422);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "Phone Number";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(601, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(186, 21);
            this.label6.TabIndex = 5;
            this.label6.Text = "The type of property";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(590, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(227, 21);
            this.label8.TabIndex = 7;
            this.label8.Text = "The value of the property";
            this.label8.Click += new System.EventHandler(this.Label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(595, 262);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 21);
            this.label9.TabIndex = 8;
            this.label9.Text = "Zone";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(595, 208);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 21);
            this.label11.TabIndex = 10;
            this.label11.Text = "Status";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(595, 342);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 21);
            this.label12.TabIndex = 11;
            this.label12.Text = "Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(598, 304);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(167, 21);
            this.label13.TabIndex = 12;
            this.label13.Text = "Number Of Rooms";
            // 
            // Pro_N_textBox1
            // 
            this.Pro_N_textBox1.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.Pro_N_textBox1.Location = new System.Drawing.Point(426, 10);
            this.Pro_N_textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Pro_N_textBox1.Name = "Pro_N_textBox1";
            this.Pro_N_textBox1.Size = new System.Drawing.Size(168, 30);
            this.Pro_N_textBox1.TabIndex = 13;
            // 
            // fullN_textBox2
            // 
            this.fullN_textBox2.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.fullN_textBox2.Location = new System.Drawing.Point(426, 373);
            this.fullN_textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fullN_textBox2.Name = "fullN_textBox2";
            this.fullN_textBox2.Size = new System.Drawing.Size(168, 30);
            this.fullN_textBox2.TabIndex = 14;
            // 
            // mob_textBox3
            // 
            this.mob_textBox3.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.mob_textBox3.Location = new System.Drawing.Point(426, 409);
            this.mob_textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mob_textBox3.Name = "mob_textBox3";
            this.mob_textBox3.Size = new System.Drawing.Size(168, 30);
            this.mob_textBox3.TabIndex = 15;
            // 
            // cost_textBox4
            // 
            this.cost_textBox4.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cost_textBox4.Location = new System.Drawing.Point(425, 87);
            this.cost_textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cost_textBox4.Name = "cost_textBox4";
            this.cost_textBox4.Size = new System.Drawing.Size(168, 30);
            this.cost_textBox4.TabIndex = 16;
            // 
            // stat_comboBox1
            // 
            this.stat_comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stat_comboBox1.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.stat_comboBox1.FormattingEnabled = true;
            this.stat_comboBox1.Items.AddRange(new object[] {
            "جديد",
            "جيد",
            "مقبول"});
            this.stat_comboBox1.Location = new System.Drawing.Point(426, 202);
            this.stat_comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.stat_comboBox1.Name = "stat_comboBox1";
            this.stat_comboBox1.Size = new System.Drawing.Size(168, 30);
            this.stat_comboBox1.TabIndex = 18;
            // 
            // Type_comboBox2
            // 
            this.Type_comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Type_comboBox2.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.Type_comboBox2.FormattingEnabled = true;
            this.Type_comboBox2.Items.AddRange(new object[] {
            "منزل",
            "شقة",
            "متجر"});
            this.Type_comboBox2.Location = new System.Drawing.Point(426, 48);
            this.Type_comboBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Type_comboBox2.Name = "Type_comboBox2";
            this.Type_comboBox2.Size = new System.Drawing.Size(168, 30);
            this.Type_comboBox2.TabIndex = 19;
            // 
            // Co_Type_comboBox3
            // 
            this.Co_Type_comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Co_Type_comboBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Co_Type_comboBox3.FormattingEnabled = true;
            this.Co_Type_comboBox3.Items.AddRange(new object[] {
            "بيع",
            "ايجار"});
            this.Co_Type_comboBox3.Location = new System.Drawing.Point(426, 163);
            this.Co_Type_comboBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Co_Type_comboBox3.Name = "Co_Type_comboBox3";
            this.Co_Type_comboBox3.Size = new System.Drawing.Size(168, 30);
            this.Co_Type_comboBox3.TabIndex = 20;
            // 
            // Region_comboBox4
            // 
            this.Region_comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Region_comboBox4.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.Region_comboBox4.FormattingEnabled = true;
            this.Region_comboBox4.Items.AddRange(new object[] {
            "المزة",
            "المالكي",
            "الميدان",
            "المهاحرين"});
            this.Region_comboBox4.Location = new System.Drawing.Point(426, 257);
            this.Region_comboBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Region_comboBox4.Name = "Region_comboBox4";
            this.Region_comboBox4.Size = new System.Drawing.Size(168, 30);
            this.Region_comboBox4.TabIndex = 21;
            // 
            // Room_UpDown1
            // 
            this.Room_UpDown1.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.Room_UpDown1.Location = new System.Drawing.Point(426, 295);
            this.Room_UpDown1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Room_UpDown1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.Room_UpDown1.Name = "Room_UpDown1";
            this.Room_UpDown1.Size = new System.Drawing.Size(169, 30);
            this.Room_UpDown1.TabIndex = 22;
            // 
            // Area_textBox6
            // 
            this.Area_textBox6.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.Area_textBox6.Location = new System.Drawing.Point(426, 124);
            this.Area_textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Area_textBox6.Name = "Area_textBox6";
            this.Area_textBox6.Size = new System.Drawing.Size(168, 30);
            this.Area_textBox6.TabIndex = 23;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(426, 337);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(168, 30);
            this.dateTimePicker1.TabIndex = 24;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(74, 178);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(230, 38);
            this.button1.TabIndex = 25;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Nn_textBox8
            // 
            this.Nn_textBox8.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.Nn_textBox8.Location = new System.Drawing.Point(426, 449);
            this.Nn_textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Nn_textBox8.Name = "Nn_textBox8";
            this.Nn_textBox8.Size = new System.Drawing.Size(168, 30);
            this.Nn_textBox8.TabIndex = 31;
            this.Nn_textBox8.TextChanged += new System.EventHandler(this.Nn_textBox8_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(595, 454);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 21);
            this.label14.TabIndex = 30;
            this.label14.Text = "ID Number";
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Bold);
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Location = new System.Drawing.Point(74, 263);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(230, 38);
            this.button7.TabIndex = 95;
            this.button7.Text = "Back to Employee Page";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // unameerror
            // 
            this.unameerror.AutoSize = true;
            this.unameerror.ForeColor = System.Drawing.Color.Red;
            this.unameerror.Location = new System.Drawing.Point(422, 496);
            this.unameerror.Name = "unameerror";
            this.unameerror.Size = new System.Drawing.Size(0, 17);
            this.unameerror.TabIndex = 98;
            // 
            // used_label
            // 
            this.used_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.used_label.Location = new System.Drawing.Point(365, 512);
            this.used_label.Name = "used_label";
            this.used_label.Size = new System.Drawing.Size(230, 31);
            this.used_label.TabIndex = 99;
            this.used_label.Click += new System.EventHandler(this.Used_label_Click);
            // 
            // Add_property
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(829, 544);
            this.Controls.Add(this.used_label);
            this.Controls.Add(this.unameerror);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.Nn_textBox8);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Area_textBox6);
            this.Controls.Add(this.Room_UpDown1);
            this.Controls.Add(this.Region_comboBox4);
            this.Controls.Add(this.Co_Type_comboBox3);
            this.Controls.Add(this.Type_comboBox2);
            this.Controls.Add(this.stat_comboBox1);
            this.Controls.Add(this.cost_textBox4);
            this.Controls.Add(this.mob_textBox3);
            this.Controls.Add(this.fullN_textBox2);
            this.Controls.Add(this.Pro_N_textBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Add_property";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add a property";
            this.Load += new System.EventHandler(this.Add_property_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Room_UpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox Pro_N_textBox1;
        private System.Windows.Forms.TextBox fullN_textBox2;
        private System.Windows.Forms.TextBox mob_textBox3;
        private System.Windows.Forms.TextBox cost_textBox4;
        private System.Windows.Forms.ComboBox stat_comboBox1;
        private System.Windows.Forms.ComboBox Type_comboBox2;
        private System.Windows.Forms.ComboBox Co_Type_comboBox3;
        private System.Windows.Forms.ComboBox Region_comboBox4;
        private System.Windows.Forms.NumericUpDown Room_UpDown1;
        private System.Windows.Forms.TextBox Area_textBox6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Nn_textBox8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label unameerror;
        private System.Windows.Forms.Label used_label;
    }
}