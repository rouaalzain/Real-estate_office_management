﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ipg201_F21
{

    


    public partial class AdminWindo : Form
    {
        private DbEntities db = new DbEntities();

        // private int count1;
       

        public AdminWindo()
        {
            InitializeComponent();


            var reports1 = db.Properties.GroupBy(e => e.User_ID).Select(n => new { رقم_الموظف = n.Key, عدد_العقارات_المسجلة = n.Count() }).ToList();
             reports.DataSource = reports1;

            var reports2 = db.AppointmentBookings.GroupBy(e => e.User_ID).Select(w => new { رقم_الموظف = w.Key, عدد_المواعيد_المحجوزة = w.Count() }).ToList();
            reports_App.DataSource = reports2;

            


            var plist = (from s in db.Properties
                         where (s.Customer.idnumber.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID) || ( s.Customer.fullname.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID)
                         select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.Customer.idnumber, s.ContractType_, s.TypeOfProperty_ }).ToList();
            dataGrid.DataSource = plist;



            var Applist = (from s in db.AppointmentBookings
                           where s.Customer_ID == s.Customer.Id
                           select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.User.username, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
            dataGridView3.DataSource = Applist;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string error = "";
            if (unameerror.Text != "")
                error += "الاسم غير متاج يرجى اختيار اسم آخر\n";

            if (password1_txt.Text == "")
                error += "أدخل كلمة مرور\n";
            if (password2_txt.Text == "")
                error += "تأكد من كلمة مرور\n";
            if (password1_txt.Text == "" || password2_txt.Text == "")
                error += "أدخل كلمة مرور\n";

            if (name_txt.Text.Trim() == "")
                error += "الرجاء كتابة الاسم\n";
            if (password1_txt.Text != password2_txt.Text)
                error += "كلمات المرور غير متطابقة\n";
            if (error == "")
            {
                User newnser = new User();
                newnser.accesslevel = "Employee";
                newnser.password = password2_txt.Text;
                newnser.username = name_txt.Text;
                db.Users.Add(newnser);
                db.SaveChanges();
                MessageBox.Show("تمت الاضافة بنجاح");
              //  this.Close();
            }
            else
            {
                MessageBox.Show(error);
            }

            
        }

        private void name_txt_TextChanged(object sender, EventArgs e)
        {
            
              if (name_txt.Text != "")
            {
                var res = (from s in db.Users
                           where s.username == name_txt.Text
                           select s).ToList();
                bool used = false;
                foreach (var re in res)
                {
                    used = true;
                    break;
                }
                if (used)
                    unameerror.Text = "الاسم مستخدم سابقاً";
                else
                    unameerror.Text = "";
            }
            else unameerror.Text = "";
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Login f = new Login();
            f.Show();
            this.Hide();
        }

        private void AdminWindo_Load(object sender, EventArgs e)
        {

        }


        //-------------------------------------
        private int Appointment_id;


        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Appointment_id = Convert.ToInt32(dataGridView3.Rows[e.RowIndex].Cells[0].Value);
            Time1textBox1.Text = Convert.ToString(dataGridView3.Rows[e.RowIndex].Cells[5].Value);
            dateTimePicker1.Text = Convert.ToString(dataGridView3.Rows[e.RowIndex].Cells[4].Value);
        }
        //------------------------------------------------------
        private void button9_Click(object sender, EventArgs e)
        {
            AppointmentBooking A = db.AppointmentBookings.Find(Appointment_id);
            try
            {

                A.Booking_date = Convert.ToDateTime(dateTimePicker1.Text);
                A.Time = Convert.ToInt32(Time1textBox1.Text);

                db.SaveChanges();
                MessageBox.Show("تم التعديل" + A.Time + A.Booking_date);

                var Applist = (from s in db.AppointmentBookings
                               where  s.Customer_ID == s.Customer.Id
                               select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.User.username, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
                dataGridView3.DataSource = Applist;


            }
            catch
            {
                MessageBox.Show("حدد الموعد المراد تعديله وتحقق من الإدخال");

            }

        }
        //---------------------------------------------------------------------------
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                AppointmentBooking m = db.AppointmentBookings.Find(Appointment_id);

                db.AppointmentBookings.Remove(m);

                db.SaveChanges();

                MessageBox.Show("تم الحذف");

                var Applist = (from s in db.AppointmentBookings
                               where s.Customer_ID == s.Customer.Id
                               select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.User.username, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
                dataGridView3.DataSource = Applist;


            }
            catch
            {
                MessageBox.Show("حدد الموعد المراد حذفه");

            }
           
        }
        //---------------------------------------------------------------------------
        private void button4_Click(object sender, EventArgs e)
        {
            Edit_groupBox5.Enabled = true;
        }

        private void search_textbox2_TextChanged(object sender, EventArgs e)
        {

            var Alist = (from s in db.AppointmentBookings
                         where (s.User.username.Contains(search_textbox2.Text)) 
                         || ( s.Customer.fullname.Contains(search_textbox2.Text) && s.Customer_ID == s.Customer.Id) 
                         ||  (s.Customer.idnumber.Contains(search_textbox2.Text) && s.Customer_ID == s.Customer.Id)
                         select new { s.Id, s.Customer.fullname, s.Customer.idnumber, s.User.username, s.Booking_date, s.Time, s.Property.PropertyNumber, s.Property.Region }).ToList();
            dataGridView3.DataSource = Alist;
        }

        //---------------------------------------------------------------------------
        private int U_id;

        private void reports_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            U_id = Convert.ToInt32(reports.Rows[e.RowIndex].Cells[0].Value);
            User z = db.Users.Find(U_id);

            name1.Text = Convert.ToString(z.username);
            Count2.Text = Convert.ToString(reports.Rows[e.RowIndex].Cells[1].Value);
            Count3.Text = Convert.ToString(reports_App.Rows[e.RowIndex].Cells[1].Value);


        }

        private void reports_App_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {

            AdminWindo f = new AdminWindo();
            f.Show();
            this.Hide();


        }
        //---------------------------------------------------------------------------
        private int _idProEdit;

        private void dataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            _idProEdit = Convert.ToInt32(dataGrid.Rows[e.RowIndex].Cells[0].Value);
            p_num.Text = Convert.ToString(dataGrid.Rows[e.RowIndex].Cells[1].Value);
            Property A = db.Properties.Find(_idProEdit);
            try
            {
                Type2.Text = Convert.ToString(A.TypeOfProperty_);
                Type1.Text = Convert.ToString(A.ContractType_);
                CostextBox4.Text = Convert.ToString(A.Cost);
                textBox1.Text = Convert.ToString(A.Area);
                Status.Text = Convert.ToString(A.StatusOfProperty_);
                comboBox1.Text = Convert.ToString(A.Region);
                MemoryStream ms = new MemoryStream(A.pic);

            }
            catch
            {
                MessageBox.Show("حدد الموعد المراد تعديله وتحقق من الإدخال");

            }
        }

        

        private void button12_Click(object sender, EventArgs e)
        {
            groupBox5.Enabled = true;

        }

        private void button10_Click(object sender, EventArgs e)
        {

            string errormsg = "";
            

            if (p_num.Text == "" || Type2.Text == "" // نوع العقار
                || CostextBox4.Text == "" || textBox1.Text == "" // المساحة والسعر
                || Type1.Text == "" || Status.Text == "" // نوع التعاقد
                || comboBox1.Text == ""  // المنطقة
                )
                errormsg += "تأكد من الإدخال\n";


            Property Property2 = db.Properties.Find(_idProEdit);


            try
            {
                if (errormsg == "")
                {

                    Property2.PropertyNumber = Convert.ToInt32(p_num.Text);// رقم العقار
                    Property2.TypeOfProperty_ = Type2.Text; // نوع العقار
                    Property2.StatusOfProperty_ = Status.Text;//حالة العقار
                    Property2.Region = comboBox1.Text;//المنطقة
                    Property2.Area = Convert.ToDecimal(textBox1.Text); // المساحة
                    Property2.ContractType_ = Type1.Text;// نوع التعاقد
                    Property2.RoomsNumber = Convert.ToInt32(numericUpDown1.Text); // عدد الغرف
                    Property2.Cost = Convert.ToInt32(CostextBox4.Text); // قيمة العقار
                    Property2.Owner_ID = Convert.ToInt32(Property2.Owner_ID);//----------------- معرف المالك يلي حددو المستخدم
                    MemoryStream pr = new MemoryStream();
                    Property2.pic = pr.ToArray();
                    try
                    {
                        db.SaveChanges();
                        MessageBox.Show("تم التعديل بنجاح");

                        var plist = (from s in db.Properties
                                     where ( s.Customer.idnumber.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID) || ( s.Customer.fullname.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID)
                                     select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.Customer.idnumber, s.ContractType_, s.TypeOfProperty_ }).ToList();
                        dataGrid.DataSource = plist;

                       



                    }
                    catch (Exception a)
                    {
                        MessageBox.Show("الرجاء التحقق من المعلومات");
                    }

                }
                else
                    MessageBox.Show(errormsg);
            }
            catch (Exception a)
            {
                MessageBox.Show("تحقق من المعلومات");

            }






        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            var plist = (from s in db.Properties
                         where (s.Customer.idnumber.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID) || ( s.Customer.fullname.Contains(textBox2.Text) && s.Customer.Id == s.Owner_ID)
                         select new { s.Id, s.PropertyNumber, s.Customer.fullname, s.Customer.idnumber, s.ContractType_, s.TypeOfProperty_ }).ToList();
            dataGrid.DataSource = plist;
        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Label18_Click(object sender, EventArgs e)
        {

        }

        private void Count3_TextChanged(object sender, EventArgs e)
        {

        }

        private void TabPage3_Click(object sender, EventArgs e)
        {

        }

        private void Label20_Click(object sender, EventArgs e)
        {

        }





        //--------------------------------------
    }
}
